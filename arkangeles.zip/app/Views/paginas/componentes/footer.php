<footer class="container-fluid content-space-1 bg-dark">
  <div class="row align-items-md-center text-center text-sm-start">
    <div class="col-md mb-3 mb-md-0">
      <a href="index.html" aria-label="Front">
        <img  src="../public/img/logo.png" width="100px;">
      </a>
    </div>
    <div class="col-sm mb-3 mb-sm-0">
      <ul class="list-inline list-separator mb-0">
        <li class="list-inline-item"><a class="link-sm link-secondary" href="#">Inicio</a></li>
        <li class="list-inline-item"><a class="link-sm link-secondary" href="#">Historia</a></li>
        <li class="list-inline-item"><a class="link-sm link-secondary" href="#">Galeria</a></li>
        <li class="list-inline-item"><a class="link-sm link-secondary" href="#">Campeonatos</a></li>
        <li class="list-inline-item"><a class="link-sm link-secondary" href="#">Eventos</a></li>
        <li class="list-inline-item"><a class="link-sm link-secondary" href="#">Contacto</a></li>
      </ul>
    </div>
    <div class="col-sm-auto">
      <ul class="list-inline mb-0">
        <li class="list-inline-item">
          <a class="btn btn-soft-secondary btn-xs btn-icon rounded-circle" href="#">
            <i class="bi-facebook"></i>
          </a>
        </li>
        <li class="list-inline-item">
          <a class="btn btn-soft-secondary btn-xs btn-icon rounded-circle" href="#">
            <i class="bi-google"></i>
          </a>
        </li>
        <li class="list-inline-item">
          <a class="btn btn-soft-secondary btn-xs btn-icon rounded-circle" href="#">
            <i class="bi-twitter"></i>
          </a>
        </li>
        <li class="list-inline-item">
          <a class="btn btn-soft-secondary btn-xs btn-icon rounded-circle" href="#">
            <i class="bi-github"></i>
          </a>
        </li>
      </ul>
    </div>
  </div>
</footer>